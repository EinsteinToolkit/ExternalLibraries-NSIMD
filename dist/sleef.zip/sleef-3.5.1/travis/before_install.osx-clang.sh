#!/bin/bash
set -ev
brew update
brew install openssl fftw ninja
