#!/bin/bash
set -ev
brew update
brew install gcc@6 openssl ninja
